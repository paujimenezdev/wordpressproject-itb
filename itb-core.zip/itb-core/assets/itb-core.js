(function () {
	'use strict';

	// Login / Register: alterna campos.
	document.querySelectorAll('[data-itb-auth]').forEach(function (form) {
		var mode = form.querySelector('[data-itb-mode]');
		var login = form.querySelector('[data-itb-login]');
		var reg = form.querySelector('[data-itb-register]');
		if (!mode || !reg) { return; }
		function sync() {
			var isReg = mode.value === 'register';
			reg.hidden = !isReg;
			login.hidden = isReg;
			reg.querySelectorAll('input[name="reg_user"],input[name="reg_email"],input[name="reg_pass"]').forEach(function (i) { i.required = isReg; });
			login.querySelectorAll('input[name="log"],input[name="pwd"]').forEach(function (i) { i.required = !isReg; });
		}
		mode.addEventListener('change', sync);
		sync();
	});

	// Crear/editar: vista previa en vivo.
	document.querySelectorAll('[data-itb-form]').forEach(function (form) {
		form.querySelectorAll('[data-pv-in]').forEach(function (input) {
			var target = form.querySelector('[data-pv="' + input.getAttribute('data-pv-in') + '"]');
			if (!target) { return; }
			var fallback = target.textContent;
			input.addEventListener('input', function () {
				var v = input.value.trim();
				target.textContent = v ? (input.getAttribute('data-pv-in') === 'text' && v.length > 180 ? v.slice(0, 180) + '…' : v) : (input.getAttribute('data-pv-in') === 'title' ? fallback : '');
			});
		});
		var file = form.querySelector('[data-pv-file]');
		var img = form.querySelector('[data-pv="img"]');
		var media = form.querySelector('[data-pv-media]');
		if (file && img) {
			file.addEventListener('change', function () {
				var f = file.files && file.files[0];
				if (!f || f.type.indexOf('image/') !== 0) { return; }
				var r = new FileReader();
				r.onload = function (e) { img.src = e.target.result; media.hidden = false; };
				r.readAsDataURL(f);
			});
		}
		var btn = form.querySelector('[data-itb-toggle-preview]');
		var wrap = form.querySelector('[data-itb-preview-wrap]');
		if (btn && wrap) {
			btn.addEventListener('click', function () {
				wrap.classList.toggle('is-open');
				wrap.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
			});
		}
	});
})();
