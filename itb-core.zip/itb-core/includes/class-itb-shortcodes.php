<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ITB_Shortcodes {

	public static function init() {
		foreach ( array( 'home', 'restaurants', 'auth', 'login', 'my_restaurant', 'restaurant_form', 'restaurant', 'sponsor', 'sidebar' ) as $tag ) {
			add_shortcode( 'itb_' . $tag, array( __CLASS__, $tag ) );
		}
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_filter( 'the_content', array( __CLASS__, 'single_filter' ) );
	}

	public static function assets() {
		wp_register_style( 'itb-core', ITB_CORE_URL . 'assets/itb-core.css', array(), ITB_CORE_VERSION );
		wp_register_script( 'itb-core', ITB_CORE_URL . 'assets/itb-core.js', array(), ITB_CORE_VERSION, true );
	}

	private static function load() {
		wp_enqueue_style( 'itb-core' );
		wp_enqueue_script( 'itb-core' );
	}

	private static function wrap( $name, $html ) {
		return '<div class="itb itb-' . esc_attr( $name ) . '">' . self::notice() . $html . '</div>';
	}

	private static function notice() {
		$code = isset( $_GET['itb_msg'] ) ? sanitize_key( wp_unslash( $_GET['itb_msg'] ) ) : '';
		$map  = array(
			'welcome'        => array( 'ok', __( 'Welcome!', 'itb-core' ) ),
			'saved'          => array( 'ok', __( 'Restaurant saved.', 'itb-core' ) ),
			'status'         => array( 'ok', __( 'Status updated.', 'itb-core' ) ),
			'review_ok'      => array( 'ok', __( 'Thanks, your review was saved.', 'itb-core' ) ),
			'login_failed'   => array( 'err', __( 'Wrong username or password.', 'itb-core' ) ),
			'reg_closed'     => array( 'err', __( 'Registration is closed. Enable "Anyone can register" in Settings → General.', 'itb-core' ) ),
			'reg_invalid'    => array( 'err', __( 'Check the fields: valid email and a password of at least 8 characters.', 'itb-core' ) ),
			'reg_exists'     => array( 'err', __( 'That username or email is already registered.', 'itb-core' ) ),
			'rest_invalid'   => array( 'err', __( 'The restaurant needs a name.', 'itb-core' ) ),
			'review_invalid' => array( 'err', __( 'Choose a score from 1 to 5 in every category.', 'itb-core' ) ),
			'forbidden'      => array( 'err', __( 'You are not allowed to do that.', 'itb-core' ) ),
		);
		if ( ! isset( $map[ $code ] ) ) {
			return '';
		}
		return '<p class="itb-notice itb-notice--' . esc_attr( $map[ $code ][0] ) . '" role="status">' . esc_html( $map[ $code ][1] ) . '</p>';
	}

	private static function score( $id, $big = false ) {
		$n = (int) get_post_meta( $id, 'itb_reviews', true );
		$r = (float) get_post_meta( $id, 'itb_rating', true );
		return '<span class="itb-score' . ( $big ? ' itb-score--lg' : '' ) . '" title="' . esc_attr( sprintf( _n( '%d review', '%d reviews', $n, 'itb-core' ), $n ) ) . '">' . ( $n ? esc_html( number_format_i18n( $r, 1 ) ) : '–' ) . '</span>';
	}

	/** Tarjeta de restaurante. $extra = HTML bajo el texto (botones, etc.). */
	private static function card( $id, $extra = '' ) {
		$live = 'publish' === get_post_status( $id );
		$link = $live ? get_permalink( $id ) : '';
		$loc  = get_post_meta( $id, 'itb_location', true );
		$img  = get_the_post_thumbnail( $id, 'large', array( 'loading' => 'lazy' ) );
		$h    = '<article class="itb-card">';
		if ( $img ) {
			$h .= '<div class="itb-card__media">' . ( $link ? '<a href="' . esc_url( $link ) . '" tabindex="-1" aria-hidden="true">' . $img . '</a>' : $img ) . '</div>';
		}
		$title = esc_html( get_the_title( $id ) );
		$h    .= '<div class="itb-card__body"><div class="itb-card__head"><h3 class="itb-card__title">' . ( $link ? '<a href="' . esc_url( $link ) . '">' . $title . '</a>' : $title ) . '</h3>' . self::score( $id ) . '</div>';
		if ( $loc ) {
			$h .= '<p class="itb-card__loc">' . esc_html( $loc ) . '</p>';
		}
		if ( ! $live ) {
			$h .= '<p class="itb-badge">' . esc_html__( 'Hidden', 'itb-core' ) . '</p>';
		}
		return $h . $extra . '</div></article>';
	}

	private static function row( $id ) {
		$loc = get_post_meta( $id, 'itb_location', true );
		$img = get_the_post_thumbnail( $id, 'thumbnail', array( 'loading' => 'lazy' ) );
		return '<li class="itb-row"><a class="itb-row__img" href="' . esc_url( get_permalink( $id ) ) . '" tabindex="-1" aria-hidden="true">' . $img . '</a><div class="itb-row__txt"><h3><a href="' . esc_url( get_permalink( $id ) ) . '">' . esc_html( get_the_title( $id ) ) . '</a></h3><p>' . esc_html( $loc ) . '</p></div>' . self::score( $id ) . '</li>';
	}

	private static function login_prompt() {
		return '<div class="itb-panel"><p>' . esc_html__( 'Log in to continue.', 'itb-core' ) . ' <a class="itb-link" href="' . esc_url( ITB_Data::auth_url() ) . '">' . esc_html__( 'Log in', 'itb-core' ) . '</a></p></div>';
	}

	private static function sponsor_html( $post ) {
		if ( ! $post ) {
			return '<div class="itb-sponsor itb-sponsor--empty"><span>' . esc_html__( 'Sponsor', 'itb-core' ) . '</span></div>';
		}
		$url = get_post_meta( $post->ID, 'itb_url', true );
		$in  = get_the_post_thumbnail( $post->ID, 'medium_large' );
		if ( ! $in ) {
			$in = '<strong>' . esc_html( get_the_title( $post ) ) . '</strong>';
		}
		$in .= '<span class="itb-sponsor__tag">' . esc_html__( 'Sponsor', 'itb-core' ) . '</span>';
		return '<div class="itb-sponsor">' . ( $url ? '<a href="' . esc_url( $url ) . '" target="_blank" rel="sponsored noopener">' . $in . '</a>' : $in ) . '</div>';
	}

	private static function sponsors( $n ) {
		$posts = get_posts( array( 'post_type' => ITB_Data::S, 'numberposts' => $n, 'orderby' => 'rand', 'post_status' => 'publish' ) );
		$out   = array();
		for ( $i = 0; $i < $n; $i++ ) {
			$out[] = self::sponsor_html( isset( $posts[ $i ] ) ? $posts[ $i ] : null );
		}
		return $out;
	}

	/* ---------------------------------------------------------------
	 * [itb_sponsor]
	 * ------------------------------------------------------------- */
	public static function sponsor() {
		self::load();
		$s = self::sponsors( 1 );
		return '<div class="itb itb-sponsor-wrap">' . $s[0] . '</div>';
	}

	/* ---------------------------------------------------------------
	 * [itb_home limit="5"]  Buscador + más famosos + patrocinadores
	 * ------------------------------------------------------------- */
	public static function home( $atts = array() ) {
		$atts = shortcode_atts( array( 'limit' => 5 ), $atts, 'itb_home' );
		self::load();
		$sp = self::sponsors( 2 );
		$q  = new WP_Query( array(
			'post_type'           => ITB_Data::R,
			'post_status'         => 'publish',
			'posts_per_page'      => max( 1, (int) $atts['limit'] ),
			'meta_key'            => 'itb_rating',
			'orderby'             => 'meta_value_num',
			'order'               => 'DESC',
			'ignore_sticky_posts' => true,
			'no_found_rows'       => true,
		) );
		$rows = '';
		while ( $q->have_posts() ) {
			$q->the_post();
			$rows .= self::row( get_the_ID() );
		}
		wp_reset_postdata();

		$h  = '<div class="itb-home__grid"><aside class="itb-home__ad">' . $sp[0] . '</aside><section class="itb-home__main">';
		$h .= '<form class="itb-search" role="search" method="get" action="' . esc_url( ITB_Data::page_url( 'itb_restaurants' ) ) . '">';
		$h .= '<input type="search" name="itb_q" class="itb-input" placeholder="' . esc_attr__( 'Search restaurants', 'itb-core' ) . '" aria-label="' . esc_attr__( 'Search restaurants', 'itb-core' ) . '">';
		$h .= '<button type="submit" class="itb-btn">' . esc_html__( 'Search', 'itb-core' ) . '</button></form>';
		$h .= '<div class="itb-panel"><h2 class="itb-h">' . esc_html__( 'Most famous restaurants', 'itb-core' ) . '</h2>';
		$h .= $rows ? '<ol class="itb-rows">' . $rows . '</ol>' : '<p>' . esc_html__( 'No restaurants yet.', 'itb-core' ) . '</p>';
		$h .= '</div></section><aside class="itb-home__ad itb-home__ad--end">' . $sp[1] . '</aside></div>';
		return self::wrap( 'home', $h );
	}

	/* ---------------------------------------------------------------
	 * [itb_restaurants per_page="9"]  Listado con filtros + pestaña "For you"
	 * ------------------------------------------------------------- */
	public static function restaurants( $atts = array() ) {
		$atts = shortcode_atts( array( 'per_page' => 9 ), $atts, 'itb_restaurants' );
		self::load();

		$get = function ( $k ) {
			return isset( $_GET[ $k ] ) ? sanitize_text_field( wp_unslash( $_GET[ $k ] ) ) : '';
		};
		$tab   = 'for-you' === $get( 'itb_tab' ) ? 'for-you' : 'all';
		$q     = $get( 'itb_q' );
		$loc   = $get( 'itb_loc' );
		$min   = (float) $get( 'itb_min' );
		$sort  = 'new' === $get( 'itb_sort' ) ? 'new' : 'rating';
		$paged = max( 1, (int) $get( 'itb_page' ) );

		$args = array(
			'post_type'           => ITB_Data::R,
			'post_status'         => 'publish',
			'posts_per_page'      => max( 1, (int) $atts['per_page'] ),
			'paged'               => $paged,
			'ignore_sticky_posts' => true,
		);
		if ( $q ) {
			$args['s'] = $q;
		}
		$meta = array( 'relation' => 'AND' );
		if ( $loc ) {
			$meta[] = array( 'key' => 'itb_location', 'value' => $loc, 'compare' => 'LIKE' );
		}
		if ( $min > 0 ) {
			$meta[] = array( 'key' => 'itb_rating', 'value' => $min, 'type' => 'NUMERIC', 'compare' => '>=' );
		}
		if ( count( $meta ) > 1 ) {
			$args['meta_query'] = $meta;
		}
		if ( 'new' === $sort ) {
			$args['orderby'] = 'date';
		} else {
			$args['meta_key'] = 'itb_rating';
			$args['orderby']  = array( 'meta_value_num' => 'DESC', 'date' => 'DESC' );
		}

		$note = '';
		if ( 'for-you' === $tab ) {
			if ( ! is_user_logged_in() ) {
				$note = '<p class="itb-notice">' . esc_html__( 'Log in to get suggestions based on places you reviewed. Showing top rated for now.', 'itb-core' ) . '</p>';
			} else {
				$mine = get_comments( array( 'user_id' => get_current_user_id(), 'type' => 'itb_review', 'number' => 0 ) );
				$ids  = array_unique( wp_list_pluck( $mine, 'comment_post_ID' ) );
				$locs = array();
				foreach ( $ids as $pid ) {
					$l = get_post_meta( $pid, 'itb_location', true );
					if ( $l ) {
						$locs[] = $l;
					}
				}
				if ( $locs ) {
					$args['post__not_in'] = $ids;
					$args['meta_query']   = array( 'relation' => 'AND', array( 'key' => 'itb_location', 'value' => array_values( array_unique( $locs ) ), 'compare' => 'IN' ) );
				} else {
					$note = '<p class="itb-notice">' . esc_html__( 'Review a few restaurants and we will suggest more like them. Showing top rated for now.', 'itb-core' ) . '</p>';
				}
			}
		}

		$base = get_permalink( get_queried_object_id() );
		$base = $base ? $base : home_url( '/' );
		$tabs = '<nav class="itb-tabs" aria-label="' . esc_attr__( 'Restaurant lists', 'itb-core' ) . '"><a href="' . esc_url( $base ) . '"' . ( 'all' === $tab ? ' aria-current="page"' : '' ) . '>' . esc_html__( 'Restaurants', 'itb-core' ) . '</a><a href="' . esc_url( add_query_arg( 'itb_tab', 'for-you', $base ) ) . '"' . ( 'for-you' === $tab ? ' aria-current="page"' : '' ) . '>' . esc_html__( 'For you', 'itb-core' ) . '</a></nav>';

		$mins = array( '' => __( 'Any score', 'itb-core' ), '3' => '3+', '4' => '4+', '4.5' => '4.5+' );
		$f    = '<form class="itb-filters" method="get" action="' . esc_url( $base ) . '">';
		if ( 'for-you' === $tab ) {
			$f .= '<input type="hidden" name="itb_tab" value="for-you">';
		}
		$f .= '<input class="itb-input" type="search" name="itb_q" value="' . esc_attr( $q ) . '" placeholder="' . esc_attr__( 'Name', 'itb-core' ) . '" aria-label="' . esc_attr__( 'Name', 'itb-core' ) . '">';
		$f .= '<input class="itb-input" type="text" name="itb_loc" value="' . esc_attr( $loc ) . '" placeholder="' . esc_attr__( 'Location', 'itb-core' ) . '" aria-label="' . esc_attr__( 'Location', 'itb-core' ) . '">';
		$f .= '<select class="itb-input" name="itb_min" aria-label="' . esc_attr__( 'Minimum score', 'itb-core' ) . '">';
		foreach ( $mins as $v => $l ) {
			$f .= '<option value="' . esc_attr( $v ) . '"' . selected( (string) $min === (string) $v || ( 0.0 === $min && '' === $v ), true, false ) . '>' . esc_html( $l ) . '</option>';
		}
		$f .= '</select><select class="itb-input" name="itb_sort" aria-label="' . esc_attr__( 'Sort by', 'itb-core' ) . '"><option value="rating"' . selected( $sort, 'rating', false ) . '>' . esc_html__( 'Top rated', 'itb-core' ) . '</option><option value="new"' . selected( $sort, 'new', false ) . '>' . esc_html__( 'Newest', 'itb-core' ) . '</option></select>';
		$f .= '<button type="submit" class="itb-btn">' . esc_html__( 'Filter', 'itb-core' ) . '</button></form>';

		$query = new WP_Query( $args );
		$list  = '';
		if ( $query->have_posts() ) {
			$list .= '<div class="itb-grid">';
			while ( $query->have_posts() ) {
				$query->the_post();
				$list .= self::card( get_the_ID() );
			}
			$list .= '</div>';
			$add   = array_filter( array( 'itb_q' => $q, 'itb_loc' => $loc, 'itb_min' => $min ? $min : '', 'itb_sort' => $sort, 'itb_tab' => 'for-you' === $tab ? $tab : '' ) );
			$pag   = paginate_links( array(
				'base'     => trailingslashit( $base ) . '%_%',
				'format'   => '?itb_page=%#%',
				'total'    => $query->max_num_pages,
				'current'  => $paged,
				'add_args' => $add,
				'type'     => 'list',
			) );
			if ( $pag ) {
				$list .= '<nav class="itb-pagination">' . wp_kses_post( $pag ) . '</nav>';
			}
		} else {
			$list = '<p class="itb-empty">' . esc_html__( 'No restaurants match your search.', 'itb-core' ) . '</p>';
		}
		wp_reset_postdata();

		return self::wrap( 'restaurants', $tabs . $note . $f . $list );
	}

	/* ---------------------------------------------------------------
	 * [itb_auth]  Selector Login/Register + opciones + Accept
	 * [itb_login] Solo login (botón Login)
	 * ------------------------------------------------------------- */
	public static function login() {
		return self::auth( array( 'only_login' => 'yes' ) );
	}

	public static function auth( $atts = array() ) {
		$atts = shortcode_atts( array( 'only_login' => 'no', 'title' => '' ), $atts, 'itb_auth' );
		self::load();
		if ( is_user_logged_in() ) {
			$h = '<div class="itb-panel"><p>' . esc_html__( 'You are logged in.', 'itb-core' ) . ' <a class="itb-link" href="' . esc_url( wp_logout_url( home_url( '/' ) ) ) . '">' . esc_html__( 'Log out', 'itb-core' ) . '</a></p></div>';
			return self::wrap( 'auth', $h );
		}
		$only = 'yes' === $atts['only_login'];
		$h    = '';
		if ( $atts['title'] ) {
			$h .= '<h2 class="itb-h">' . esc_html( $atts['title'] ) . '</h2>';
		}
		$h .= '<form class="itb-panel itb-form itb-auth" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" data-itb-auth>';
		$h .= '<input type="hidden" name="action" value="itb_auth">' . wp_nonce_field( 'itb_auth', '_wpnonce', true, false );
		if ( $only ) {
			$h .= '<input type="hidden" name="itb_mode" value="login">';
		} else {
			$h .= '<label class="itb-field"><span>' . esc_html__( 'I want to', 'itb-core' ) . '</span><select class="itb-input" name="itb_mode" data-itb-mode><option value="login">' . esc_html__( 'Log in', 'itb-core' ) . '</option><option value="register">' . esc_html__( 'Register', 'itb-core' ) . '</option></select></label>';
		}
		$h .= '<div data-itb-login><label class="itb-field"><span>' . esc_html__( 'Username or email', 'itb-core' ) . '</span><input class="itb-input" type="text" name="log" autocomplete="username"></label>';
		$h .= '<label class="itb-field"><span>' . esc_html__( 'Password', 'itb-core' ) . '</span><input class="itb-input" type="password" name="pwd" autocomplete="current-password"></label>';
		$h .= '<label class="itb-check"><input type="checkbox" name="rememberme" value="1"> ' . esc_html__( 'Remember me', 'itb-core' ) . '</label></div>';
		if ( ! $only ) {
			$h .= '<div data-itb-register hidden><label class="itb-field"><span>' . esc_html__( 'Username', 'itb-core' ) . '</span><input class="itb-input" type="text" name="reg_user" autocomplete="username"></label>';
			$h .= '<label class="itb-field"><span>' . esc_html__( 'Email', 'itb-core' ) . '</span><input class="itb-input" type="email" name="reg_email" autocomplete="email"></label>';
			$h .= '<label class="itb-field"><span>' . esc_html__( 'Password (8+ characters)', 'itb-core' ) . '</span><input class="itb-input" type="password" name="reg_pass" minlength="8" autocomplete="new-password"></label>';
			$h .= '<label class="itb-field"><span>' . esc_html__( 'Account type', 'itb-core' ) . '</span><select class="itb-input" name="reg_type"><option value="customer">' . esc_html__( 'Customer', 'itb-core' ) . '</option><option value="owner">' . esc_html__( 'Restaurant owner', 'itb-core' ) . '</option></select></label></div>';
		}
		$h .= '<button type="submit" class="itb-btn">' . esc_html( $only ? __( 'Log in', 'itb-core' ) : __( 'Accept', 'itb-core' ) ) . '</button></form>';
		return self::wrap( 'auth', $h );
	}

	/* ---------------------------------------------------------------
	 * [itb_my_restaurant]  "Your restaurant" + Create / Edit / Status
	 * ------------------------------------------------------------- */
	public static function my_restaurant() {
		self::load();
		if ( ! is_user_logged_in() ) {
			return self::wrap( 'mine', self::login_prompt() );
		}
		if ( ! ITB_Data::is_owner() ) {
			return self::wrap( 'mine', '<div class="itb-panel"><p>' . esc_html__( 'Only restaurant owner accounts can manage restaurants.', 'itb-core' ) . '</p></div>' );
		}
		$form = ITB_Data::page_url( 'itb_restaurant_form' );
		$h    = '<div class="itb-bar"><h2 class="itb-h">' . esc_html__( 'Your restaurant', 'itb-core' ) . '</h2><a class="itb-btn" href="' . esc_url( $form ) . '">' . esc_html__( 'Create', 'itb-core' ) . '</a></div>';

		$posts = get_posts( array( 'post_type' => ITB_Data::R, 'author' => get_current_user_id(), 'post_status' => array( 'publish', 'draft' ), 'numberposts' => 50 ) );
		if ( ! $posts ) {
			$h .= '<div class="itb-panel"><p>' . esc_html__( 'You have not created a restaurant yet.', 'itb-core' ) . '</p></div>';
		} else {
			$h .= '<div class="itb-grid">';
			foreach ( $posts as $p ) {
				$live  = 'publish' === $p->post_status;
				$extra = '<div class="itb-actions"><a class="itb-btn itb-btn--ghost" href="' . esc_url( add_query_arg( 'restaurant', $p->ID, $form ) ) . '">' . esc_html__( 'Edit', 'itb-core' ) . '</a>';
				$extra .= '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="itb_toggle_status"><input type="hidden" name="restaurant_id" value="' . (int) $p->ID . '">' . wp_nonce_field( 'itb_status_' . $p->ID, '_wpnonce', true, false );
				$extra .= '<button type="submit" class="itb-btn itb-btn--ghost">' . esc_html( $live ? __( 'Status: visible', 'itb-core' ) : __( 'Status: hidden', 'itb-core' ) ) . '</button></form></div>';
				$h     .= self::card( $p->ID, $extra );
			}
			$h .= '</div>';
		}
		return self::wrap( 'mine', $h );
	}

	/* ---------------------------------------------------------------
	 * [itb_restaurant_form]  Crear / editar (Name, Location, Image, Description)
	 * ------------------------------------------------------------- */
	public static function restaurant_form() {
		self::load();
		if ( ! is_user_logged_in() ) {
			return self::wrap( 'form', self::login_prompt() );
		}
		if ( ! ITB_Data::is_owner() ) {
			return self::wrap( 'form', '<div class="itb-panel"><p>' . esc_html__( 'Only restaurant owner accounts can manage restaurants.', 'itb-core' ) . '</p></div>' );
		}
		$id = isset( $_GET['restaurant'] ) ? (int) $_GET['restaurant'] : 0;
		if ( $id && ! ITB_Data::can_manage( $id ) ) {
			return self::wrap( 'form', '<div class="itb-panel"><p>' . esc_html__( 'You are not allowed to edit this restaurant.', 'itb-core' ) . '</p></div>' );
		}
		$p      = $id ? get_post( $id ) : null;
		$name   = $p ? $p->post_title : '';
		$loc    = $p ? get_post_meta( $id, 'itb_location', true ) : '';
		$desc   = $p ? $p->post_content : '';
		$status = $p ? $p->post_status : 'draft';
		$img    = $p ? get_the_post_thumbnail_url( $id, 'large' ) : '';

		$h  = '<form class="itb-form" method="post" enctype="multipart/form-data" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" data-itb-form>';
		$h .= '<input type="hidden" name="action" value="itb_save_restaurant"><input type="hidden" name="restaurant_id" value="' . (int) $id . '">' . wp_nonce_field( 'itb_save', '_wpnonce', true, false );
		$h .= '<div class="itb-bar"><a class="itb-btn itb-btn--ghost" href="' . esc_url( ITB_Data::page_url( 'itb_my_restaurant' ) ) . '">' . esc_html__( 'Back', 'itb-core' ) . '</a>';
		$h .= '<label class="itb-inline"><span>' . esc_html__( 'Status', 'itb-core' ) . '</span><select class="itb-input" name="status"><option value="publish"' . selected( $status, 'publish', false ) . '>' . esc_html__( 'Visible', 'itb-core' ) . '</option><option value="draft"' . selected( 'publish' === $status, false, false ) . '>' . esc_html__( 'Hidden', 'itb-core' ) . '</option></select></label></div>';

		$h .= '<div class="itb-form__grid"><div class="itb-panel">';
		$h .= '<label class="itb-field"><span>' . esc_html__( 'Name', 'itb-core' ) . '</span><input class="itb-input" type="text" name="title" required maxlength="120" value="' . esc_attr( $name ) . '" data-pv-in="title"></label>';
		$h .= '<label class="itb-field"><span>' . esc_html__( 'Location', 'itb-core' ) . '</span><input class="itb-input" type="text" name="location" maxlength="160" value="' . esc_attr( $loc ) . '" data-pv-in="location"></label>';
		$h .= '<label class="itb-field"><span>' . esc_html__( 'Image', 'itb-core' ) . '</span><input class="itb-input" type="file" name="image" accept="image/jpeg,image/png,image/webp" data-pv-file></label>';
		$h .= '<label class="itb-field"><span>' . esc_html__( 'Description', 'itb-core' ) . '</span><textarea class="itb-input" name="description" rows="6" data-pv-in="text">' . esc_textarea( $desc ) . '</textarea></label>';
		$h .= '</div><div class="itb-preview-wrap" data-itb-preview-wrap><article class="itb-card itb-preview">';
		$h .= '<div class="itb-card__media"' . ( $img ? '' : ' hidden' ) . ' data-pv-media><img src="' . esc_url( $img ) . '" alt="" data-pv="img"></div>';
		$h .= '<div class="itb-card__body"><div class="itb-card__head"><h3 class="itb-card__title" data-pv="title">' . esc_html( $name ? $name : __( 'Restaurant name', 'itb-core' ) ) . '</h3><span class="itb-score">–</span></div>';
		$h .= '<p class="itb-card__loc" data-pv="location">' . esc_html( $loc ) . '</p><p class="itb-card__excerpt" data-pv="text">' . esc_html( wp_trim_words( wp_strip_all_tags( $desc ), 30 ) ) . '</p></div></article></div></div>';

		$h .= '<div class="itb-actions"><button type="submit" class="itb-btn">' . esc_html__( 'Save', 'itb-core' ) . '</button><button type="button" class="itb-btn itb-btn--ghost" data-itb-toggle-preview>' . esc_html__( 'Preview', 'itb-core' ) . '</button></div></form>';
		return self::wrap( 'form', $h );
	}

	/* ---------------------------------------------------------------
	 * [itb_restaurant id=""]  Ficha: imagen, descripción, scores, comentarios
	 * También se aplica solo en la página individual del tipo Restaurante.
	 * ------------------------------------------------------------- */
	public static function single_filter( $content ) {
		if ( is_singular( ITB_Data::R ) && in_the_loop() && is_main_query() ) {
			return self::restaurant( array( 'id' => get_the_ID() ) );
		}
		return $content;
	}

	public static function restaurant( $atts = array() ) {
		$atts = shortcode_atts( array( 'id' => 0 ), $atts, 'itb_restaurant' );
		self::load();
		$id = (int) $atts['id'];
		if ( ! $id && isset( $_GET['itb_restaurant'] ) ) {
			$id = (int) $_GET['itb_restaurant'];
		}
		$p = $id ? get_post( $id ) : null;
		if ( ! $p || ITB_Data::R !== $p->post_type || ( 'publish' !== $p->post_status && ! ITB_Data::can_manage( $id ) ) ) {
			return self::wrap( 'detail', '<div class="itb-panel"><p>' . esc_html__( 'Restaurant not found.', 'itb-core' ) . '</p></div>' );
		}
		$loc = get_post_meta( $id, 'itb_location', true );
		$img = get_the_post_thumbnail( $id, 'large' );

		$h  = '<header class="itb-detail__head"><div><h2 class="itb-h">' . esc_html( $p->post_title ) . '</h2>' . ( $loc ? '<p class="itb-card__loc">' . esc_html( $loc ) . '</p>' : '' ) . '</div>' . self::score( $id, true ) . '</header>';
		if ( $img ) {
			$h .= '<div class="itb-panel itb-detail__img">' . $img . '</div>';
		}
		if ( $p->post_content ) {
			$h .= '<div class="itb-panel"><h3 class="itb-h">' . esc_html__( 'Description', 'itb-core' ) . '</h3>' . wp_kses_post( wpautop( $p->post_content ) ) . '</div>';
		}
		$h .= '<div class="itb-panel"><h3 class="itb-h">' . esc_html__( 'Scores', 'itb-core' ) . '</h3><dl class="itb-scores">';
		foreach ( ITB_Data::scores() as $k => $label ) {
			$h .= '<div><dt>' . esc_html( $label ) . '</dt><dd>' . esc_html( number_format_i18n( (float) get_post_meta( $id, 'itb_s_' . $k, true ), 1 ) ) . '</dd></div>';
		}
		$h .= '</dl></div>';

		// Comentarios.
		$h .= '<div class="itb-panel" id="itb-reviews"><h3 class="itb-h">' . esc_html__( 'Comments', 'itb-core' ) . '</h3>';
		$rev = get_comments( array( 'post_id' => $id, 'type' => 'itb_review', 'status' => 'approve', 'number' => 50, 'order' => 'DESC' ) );
		if ( $rev ) {
			$h .= '<ul class="itb-reviews">';
			foreach ( $rev as $c ) {
				$bits = array();
				foreach ( ITB_Data::scores() as $k => $label ) {
					$bits[] = esc_html( $label ) . ' ' . (int) get_comment_meta( $c->comment_ID, 'itb_' . $k, true );
				}
				$h .= '<li><strong>' . esc_html( $c->comment_author ) . '</strong> <span class="itb-muted">' . esc_html( get_comment_date( '', $c ) ) . '</span><p class="itb-muted">' . implode( ' · ', $bits ) . '</p>';
				$h .= $c->comment_content ? '<p>' . esc_html( $c->comment_content ) . '</p>' : '';
				$h .= '</li>';
			}
			$h .= '</ul>';
		} else {
			$h .= '<p>' . esc_html__( 'No comments yet.', 'itb-core' ) . '</p>';
		}

		if ( 'publish' === $p->post_status ) {
			if ( ! is_user_logged_in() ) {
				$h .= '<p><a class="itb-link" href="' . esc_url( ITB_Data::auth_url() ) . '">' . esc_html__( 'Log in to leave a review', 'itb-core' ) . '</a></p>';
			} elseif ( (int) $p->post_author !== get_current_user_id() ) {
				$h .= '<form class="itb-form itb-review-form" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="itb_review"><input type="hidden" name="restaurant_id" value="' . (int) $id . '">' . wp_nonce_field( 'itb_review', '_wpnonce', true, false );
				$h .= '<div class="itb-review-form__scores">';
				foreach ( ITB_Data::scores() as $k => $label ) {
					$h .= '<label class="itb-field"><span>' . esc_html( $label ) . '</span><select class="itb-input" name="score_' . esc_attr( $k ) . '" required><option value="">–</option>';
					for ( $i = 5; $i >= 1; $i-- ) {
						$h .= '<option value="' . $i . '">' . $i . '</option>';
					}
					$h .= '</select></label>';
				}
				$h .= '</div><label class="itb-field"><span>' . esc_html__( 'Your comment', 'itb-core' ) . '</span><textarea class="itb-input" name="comment" rows="3" maxlength="1500"></textarea></label>';
				$h .= '<button type="submit" class="itb-btn">' . esc_html__( 'Send review', 'itb-core' ) . '</button></form>';
			}
		}
		$h .= '</div>';
		return self::wrap( 'detail', $h );
	}

	/* ---------------------------------------------------------------
	 * [itb_sidebar]  Navegación lateral según el rol
	 * ------------------------------------------------------------- */
	public static function sidebar() {
		self::load();
		$list  = ITB_Data::page_url( 'itb_restaurants' );
		$items = array(
			array( __( 'Home', 'itb-core' ), ITB_Data::page_url( 'itb_home' ) ),
			array( __( 'Restaurants', 'itb-core' ), $list ),
			array( __( 'For you', 'itb-core' ), add_query_arg( 'itb_tab', 'for-you', $list ) ),
		);
		if ( ITB_Data::is_owner() ) {
			$items[] = array( __( 'Your restaurant', 'itb-core' ), ITB_Data::page_url( 'itb_my_restaurant' ) );
		}
		$items[] = is_user_logged_in()
			? array( __( 'Log out', 'itb-core' ), wp_logout_url( home_url( '/' ) ) )
			: array( __( 'Log in', 'itb-core' ), ITB_Data::auth_url() );

		$h = '<nav class="itb-panel itb-sidebar" aria-label="' . esc_attr__( 'Portal', 'itb-core' ) . '"><ul>';
		foreach ( $items as $i ) {
			$h .= '<li><a href="' . esc_url( $i[1] ) . '">' . esc_html( $i[0] ) . '</a></li>';
		}
		return '<div class="itb itb-sidebar-wrap">' . $h . '</ul></nav></div>';
	}
}
