<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ITB_Data {

	const R    = 'itb_restaurant';
	const S    = 'itb_sponsor';
	const ROLE = 'itb_owner';

	public static function init() {
		self::register();
		if ( ! get_role( self::ROLE ) ) {
			self::add_role();
		}
		add_action( 'add_meta_boxes', array( __CLASS__, 'meta_boxes' ) );
		add_action( 'save_post', array( __CLASS__, 'save_meta' ) );
		add_action( 'save_post_' . self::R, array( __CLASS__, 'default_meta' ) );
		add_action( 'save_post_page', function () {
			delete_transient( 'itb_pages' );
		} );
	}

	public static function scores() {
		return array(
			'food'     => __( 'Food', 'itb-core' ),
			'service'  => __( 'Service', 'itb-core' ),
			'ambience' => __( 'Ambience', 'itb-core' ),
		);
	}

	public static function register() {
		register_post_type( self::R, array(
			'labels'       => array(
				'name'          => __( 'Restaurants', 'itb-core' ),
				'singular_name' => __( 'Restaurant', 'itb-core' ),
				'add_new_item'  => __( 'Add restaurant', 'itb-core' ),
			),
			'public'       => true,
			'menu_icon'    => 'dashicons-food',
			'show_in_rest' => false,
			'rewrite'      => array( 'slug' => 'restaurant' ),
			'supports'     => array( 'title', 'editor', 'thumbnail', 'author' ),
		) );
		register_post_type( self::S, array(
			'labels'    => array(
				'name'          => __( 'Sponsors', 'itb-core' ),
				'singular_name' => __( 'Sponsor', 'itb-core' ),
				'add_new_item'  => __( 'Add sponsor', 'itb-core' ),
			),
			'public'    => false,
			'show_ui'   => true,
			'menu_icon' => 'dashicons-megaphone',
			'supports'  => array( 'title', 'thumbnail' ),
		) );
	}

	public static function add_role() {
		add_role( self::ROLE, __( 'Restaurant owner', 'itb-core' ), array( 'read' => true ) );
	}

	public static function is_owner() {
		$u = wp_get_current_user();
		return $u->exists() && ( in_array( self::ROLE, (array) $u->roles, true ) || user_can( $u, 'manage_options' ) );
	}

	public static function can_manage( $post_id ) {
		$p = get_post( $post_id );
		if ( ! $p || self::R !== $p->post_type || ! is_user_logged_in() ) {
			return false;
		}
		return current_user_can( 'manage_options' ) || ( (int) $p->post_author === get_current_user_id() && self::is_owner() );
	}

	/** Recalcula las medias de puntuación de un restaurante. */
	public static function recalc( $pid ) {
		$rev = get_comments( array( 'post_id' => $pid, 'type' => 'itb_review', 'status' => 'approve', 'number' => 0 ) );
		$n   = count( $rev );
		$sum = array_fill_keys( array_keys( self::scores() ), 0 );
		foreach ( $rev as $c ) {
			foreach ( $sum as $k => $v ) {
				$sum[ $k ] += (float) get_comment_meta( $c->comment_ID, 'itb_' . $k, true );
			}
		}
		$total = 0;
		foreach ( $sum as $k => $s ) {
			$avg    = $n ? $s / $n : 0;
			$total += $avg;
			update_post_meta( $pid, 'itb_s_' . $k, round( $avg, 1 ) );
		}
		update_post_meta( $pid, 'itb_rating', $n ? round( $total / count( $sum ), 1 ) : 0 );
		update_post_meta( $pid, 'itb_reviews', $n );
	}

	public static function default_meta( $id ) {
		add_post_meta( $id, 'itb_rating', 0, true );
		add_post_meta( $id, 'itb_reviews', 0, true );
	}

	/** URL de la primera página publicada que contiene un shortcode. */
	public static function page_url( $tag ) {
		global $wpdb;
		$cache = get_transient( 'itb_pages' );
		if ( ! is_array( $cache ) ) {
			$cache = array();
		}
		if ( ! isset( $cache[ $tag ] ) ) {
			$id = $wpdb->get_var( $wpdb->prepare(
				"SELECT ID FROM {$wpdb->posts} WHERE post_type = 'page' AND post_status = 'publish' AND post_content LIKE %s LIMIT 1",
				'%[' . $wpdb->esc_like( $tag ) . '%'
			) );
			$cache[ $tag ] = $id ? get_permalink( $id ) : '';
			set_transient( 'itb_pages', $cache, HOUR_IN_SECONDS );
		}
		return $cache[ $tag ] ? $cache[ $tag ] : home_url( '/' );
	}

	public static function auth_url() {
		$u = self::page_url( 'itb_auth' );
		return home_url( '/' ) === $u ? self::page_url( 'itb_login' ) : $u;
	}

	public static function meta_boxes() {
		add_meta_box( 'itb_loc', __( 'Location', 'itb-core' ), function ( $p ) {
			wp_nonce_field( 'itb_meta', 'itb_meta_nonce' );
			printf( '<input type="text" class="widefat" name="itb_location" value="%s">', esc_attr( get_post_meta( $p->ID, 'itb_location', true ) ) );
		}, self::R, 'side' );
		add_meta_box( 'itb_url', __( 'Sponsor link (URL)', 'itb-core' ), function ( $p ) {
			wp_nonce_field( 'itb_meta', 'itb_meta_nonce' );
			printf( '<input type="url" class="widefat" name="itb_url" value="%s">', esc_attr( get_post_meta( $p->ID, 'itb_url', true ) ) );
		}, self::S, 'side' );
	}

	public static function save_meta( $id ) {
		if ( ! isset( $_POST['itb_meta_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['itb_meta_nonce'] ) ), 'itb_meta' ) ) {
			return;
		}
		if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || ! current_user_can( 'edit_post', $id ) ) {
			return;
		}
		if ( isset( $_POST['itb_location'] ) ) {
			update_post_meta( $id, 'itb_location', sanitize_text_field( wp_unslash( $_POST['itb_location'] ) ) );
		}
		if ( isset( $_POST['itb_url'] ) ) {
			update_post_meta( $id, 'itb_url', esc_url_raw( wp_unslash( $_POST['itb_url'] ) ) );
		}
	}
}
