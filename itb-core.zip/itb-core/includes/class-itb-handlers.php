<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ITB_Handlers {

	public static function init() {
		add_action( 'admin_post_nopriv_itb_auth', array( __CLASS__, 'auth' ) );
		add_action( 'admin_post_itb_auth', array( __CLASS__, 'auth' ) );
		add_action( 'admin_post_itb_save_restaurant', array( __CLASS__, 'save_restaurant' ) );
		add_action( 'admin_post_itb_toggle_status', array( __CLASS__, 'toggle_status' ) );
		add_action( 'admin_post_itb_review', array( __CLASS__, 'review' ) );
	}

	private static function go( $url, $msg ) {
		wp_safe_redirect( add_query_arg( 'itb_msg', $msg, remove_query_arg( 'itb_msg', $url ) ) );
		exit;
	}

	private static function back() {
		$ref = wp_get_referer();
		return $ref ? $ref : home_url( '/' );
	}

	private static function post( $key ) {
		return isset( $_POST[ $key ] ) ? wp_unslash( $_POST[ $key ] ) : '';
	}

	/** Login o registro. */
	public static function auth() {
		check_admin_referer( 'itb_auth' );
		$back = self::back();
		$mode = 'register' === self::post( 'itb_mode' ) ? 'register' : 'login';

		if ( 'login' === $mode ) {
			$user = wp_signon( array(
				'user_login'    => sanitize_user( self::post( 'log' ) ),
				'user_password' => self::post( 'pwd' ),
				'remember'      => ! empty( $_POST['rememberme'] ),
			) );
			if ( is_wp_error( $user ) ) {
				self::go( $back, 'login_failed' );
			}
			self::go( self::after_login( $user ), 'welcome' );
		}

		if ( ! get_option( 'users_can_register' ) ) {
			self::go( $back, 'reg_closed' );
		}
		$login = sanitize_user( self::post( 'reg_user' ), true );
		$email = sanitize_email( self::post( 'reg_email' ) );
		$pass  = (string) self::post( 'reg_pass' );
		$type  = 'owner' === self::post( 'reg_type' ) ? 'owner' : 'customer';

		if ( '' === $login || ! is_email( $email ) || strlen( $pass ) < 8 ) {
			self::go( $back, 'reg_invalid' );
		}
		if ( username_exists( $login ) || email_exists( $email ) ) {
			self::go( $back, 'reg_exists' );
		}
		$uid = wp_create_user( $login, $pass, $email );
		if ( is_wp_error( $uid ) ) {
			self::go( $back, 'reg_invalid' );
		}
		$u = new WP_User( $uid );
		$u->set_role( 'owner' === $type ? ITB_Data::ROLE : 'subscriber' );
		wp_set_current_user( $uid );
		wp_set_auth_cookie( $uid );
		self::go( self::after_login( $u ), 'welcome' );
	}

	private static function after_login( $user ) {
		if ( in_array( ITB_Data::ROLE, (array) $user->roles, true ) ) {
			return ITB_Data::page_url( 'itb_my_restaurant' );
		}
		return ITB_Data::page_url( 'itb_restaurants' );
	}

	/** Crear o editar restaurante. */
	public static function save_restaurant() {
		check_admin_referer( 'itb_save' );
		$back = self::back();
		if ( ! ITB_Data::is_owner() ) {
			self::go( $back, 'forbidden' );
		}
		$id = (int) self::post( 'restaurant_id' );
		if ( $id && ! ITB_Data::can_manage( $id ) ) {
			self::go( $back, 'forbidden' );
		}
		$title = sanitize_text_field( self::post( 'title' ) );
		if ( '' === $title ) {
			self::go( $back, 'rest_invalid' );
		}
		$data = array(
			'post_type'    => ITB_Data::R,
			'post_title'   => $title,
			'post_content' => wp_kses_post( self::post( 'description' ) ),
			'post_status'  => 'publish' === self::post( 'status' ) ? 'publish' : 'draft',
		);
		if ( $id ) {
			$data['ID'] = $id;
			$pid        = wp_update_post( $data, true );
		} else {
			$data['post_author'] = get_current_user_id();
			$pid                 = wp_insert_post( $data, true );
		}
		if ( is_wp_error( $pid ) || ! $pid ) {
			self::go( $back, 'rest_invalid' );
		}
		update_post_meta( $pid, 'itb_location', sanitize_text_field( self::post( 'location' ) ) );

		if ( ! empty( $_FILES['image']['name'] ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
			require_once ABSPATH . 'wp-admin/includes/image.php';
			require_once ABSPATH . 'wp-admin/includes/media.php';
			$att = media_handle_upload( 'image', $pid, array(), array(
				'test_form' => false,
				'mimes'     => array( 'jpg|jpeg' => 'image/jpeg', 'png' => 'image/png', 'webp' => 'image/webp' ),
			) );
			if ( ! is_wp_error( $att ) ) {
				set_post_thumbnail( $pid, $att );
			}
		}
		self::go( ITB_Data::page_url( 'itb_my_restaurant' ), 'saved' );
	}

	/** Cambiar entre visible (publish) y oculto (draft). */
	public static function toggle_status() {
		$id = isset( $_POST['restaurant_id'] ) ? (int) $_POST['restaurant_id'] : 0;
		check_admin_referer( 'itb_status_' . $id );
		if ( ! ITB_Data::can_manage( $id ) ) {
			self::go( self::back(), 'forbidden' );
		}
		$new = 'publish' === get_post_status( $id ) ? 'draft' : 'publish';
		wp_update_post( array( 'ID' => $id, 'post_status' => $new ) );
		self::go( ITB_Data::page_url( 'itb_my_restaurant' ), 'status' );
	}

	/** Comentario + puntuaciones. */
	public static function review() {
		check_admin_referer( 'itb_review' );
		$back = self::back();
		$pid  = (int) self::post( 'restaurant_id' );
		$p    = get_post( $pid );
		if ( ! is_user_logged_in() || ! $p || ITB_Data::R !== $p->post_type || 'publish' !== $p->post_status || (int) $p->post_author === get_current_user_id() ) {
			self::go( $back, 'forbidden' );
		}
		$sc = array();
		foreach ( array_keys( ITB_Data::scores() ) as $k ) {
			$v = (int) self::post( 'score_' . $k );
			if ( $v < 1 || $v > 5 ) {
				self::go( $back, 'review_invalid' );
			}
			$sc[ $k ] = $v;
		}
		$text = sanitize_textarea_field( self::post( 'comment' ) );
		$user = wp_get_current_user();
		$old  = get_comments( array( 'post_id' => $pid, 'user_id' => $user->ID, 'type' => 'itb_review', 'number' => 1 ) );

		if ( $old ) {
			$cid = $old[0]->comment_ID;
			wp_update_comment( array( 'comment_ID' => $cid, 'comment_content' => $text ) );
		} else {
			$cid = wp_insert_comment( array(
				'comment_post_ID'      => $pid,
				'comment_content'      => $text,
				'comment_type'         => 'itb_review',
				'user_id'              => $user->ID,
				'comment_author'       => $user->display_name,
				'comment_author_email' => $user->user_email,
				'comment_approved'     => 1,
			) );
		}
		if ( ! $cid ) {
			self::go( $back, 'review_invalid' );
		}
		foreach ( $sc as $k => $v ) {
			update_comment_meta( $cid, 'itb_' . $k, $v );
		}
		ITB_Data::recalc( $pid );
		self::go( $back . '#itb-reviews', 'review_ok' );
	}
}
