<?php
/**
 * Plugin Name: ITB Core
 * Description: Shortcodes del portal de restaurantes: inicio, listado, "para ti", login/registro, mi restaurante, crear/editar y ficha con puntuaciones. Estilo liquid glass.
 * Version:     1.0.0
 * Text Domain: itb-core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'ITB_CORE_VERSION', '1.0.0' );
define( 'ITB_CORE_URL', plugin_dir_url( __FILE__ ) );
define( 'ITB_CORE_PATH', plugin_dir_path( __FILE__ ) );

require_once ITB_CORE_PATH . 'includes/class-itb-data.php';
require_once ITB_CORE_PATH . 'includes/class-itb-handlers.php';
require_once ITB_CORE_PATH . 'includes/class-itb-shortcodes.php';

register_activation_hook( __FILE__, function () {
	ITB_Data::register();
	ITB_Data::add_role();
	flush_rewrite_rules();
} );
register_deactivation_hook( __FILE__, 'flush_rewrite_rules' );

add_action( 'init', array( 'ITB_Data', 'init' ) );
add_action( 'init', array( 'ITB_Handlers', 'init' ) );
add_action( 'init', array( 'ITB_Shortcodes', 'init' ) );
